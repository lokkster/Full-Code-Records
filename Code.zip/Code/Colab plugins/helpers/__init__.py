"""Top-level package of helpers."""

__author__ = """David S."""
__email__ = 'infosmith@prontonmail.com'
__version__ = '0.2.0'
